#include "stm32f4xx.h"
#include "led.h"
#include "key.h"
#include "beep.h"
#include "delay.h"
#include "uart.h"
#include "infrared.h"
#include "us100.h"
#include "OLED.h"
#include "gy39.h"
#include "asrpro.h"
#include "timer.h"
#include <stdio.h>
#include <time.h>  
#include "clock.h"

int mode = 0;
int main()
{
	int h=17;
  int m=0;
  int s=0;
	
	int led_status = 0;
	//led_init_new(); 
	//led_init();
	key_init();
	//key_exti_init();
	//beep_init();
	infrared_init();
	
	uart1_init(9600);
	us100_init(9600);
	uint16_t distance;
	uint8_t temperature;
	
	OLED_Init();
	
	gy39_init();
	
	asrpro_init();
	
	led_pwm_init(100-1, 840-1,50);
	OLED_ShowString(1, 12, "AUTO ");
	light_ctrl(100);
	while (1)
	{
		//clock();
		printf("%d:%d:%d\n",h,m,s);
		OLED_ShowNum(2, 1,h, 2);
		OLED_ShowString(2, 3, ":");
		OLED_ShowNum(2, 4,m, 2);
		OLED_ShowString(2, 6, ":");
		OLED_ShowNum(2, 7,s, 2);
		s++;
		if(s==60)
		{
			s = 0;
			m++;
		}
		if(m==60)
		{
			m = 0;
			h++;
		}
		
		if(led_status == 1)
		{
			OLED_ShowString(1, 1, "LED  ON");
		}
		else
		{
			OLED_ShowString(1, 1, "LED OFF");
		}
		if(key_get_status(KEY0) == KEY_DOWN)
		{
			OLED_ShowString(1, 12, "VOICE");
			mode = 1;
		}
		if(key_get_status(KEY1) == KEY_DOWN)
		{
			OLED_ShowString(1, 12, "AUTO ");
			mode = 0;
		}
		if(mode == 0)
		{
				temperature = Get_Temperature();
				printf("Temperature:%d\n", temperature);
				delay_ms(50);
				distance=US100_GetDate();
				printf("Distance:%d\n",distance);
				
				printf("infrared:%d\n",infrared_get_status());
				gy39_get_LightIntensity();
				gy39_get_OtherValue();
				printf("GZ:%d WD:%d SD:%d QY:%d HB:%d\r\n",GZ,WD,SD,QY,HB);
			
				OLED_ShowString(4, 9, "GZ:");
				OLED_ShowNum(4,12,GZ, 3);
				OLED_ShowString(4, 1, "WD:");
				OLED_ShowNum(4, 4,WD, 2);
				if(distance > 1000)
				{
					
					OLED_ShowString(3, 1, "LEAVE");
					light_ctrl(0);
					led_status = 0;
					
				}
				else
				{
					OLED_ShowString(3, 1, "STAY ");
					if(GZ < 80)
					{
						printf("4\n");
						light_ctrl(98);
					}
					else if(GZ < 110)
					{
						printf("2\n");
						light_ctrl(68);
					}
					else 
					{
						printf("3\n");
						light_ctrl(10);
					}
					led_status = 1;
				}
			}
		else
		{
			static int light = 100;
			printf("voice:%d\n",asrpro_get_status());
				
			if(asrpro_get_status() == 0 && asrpro_get_status_change() == 1)
			{
				light = 0;
				led_status = 0;
			}
			else if(asrpro_get_status() == 1 && asrpro_get_status_change() == 1)
			{
				light = 50;
				led_status = 1;
			}
			
			if(asrpro_get_status_ctrl() == 1 && asrpro_get_status_change() == 0)
			{
				light = 98;
				led_status = 1;
			}
			else if(asrpro_get_status_ctrl() == 0 && asrpro_get_status_change() == 0)
			{
				light = 10;
				led_status = 1;
			}
			printf("light:%d\n", light);
			OLED_ShowString(3, 1, "light");
			OLED_ShowNum(3, 6, light, 3);
			OLED_ShowNum(3,13, asrpro_get_status_ctrl() , 1);
			OLED_ShowNum(3,15, asrpro_get_status_change() , 1);
			light_ctrl(light);
			delay_ms(1000);
		}
		

		//USART_SendDatas(USART1, (uint8_t *)"hello\r\n", 8);
			
	}
}



